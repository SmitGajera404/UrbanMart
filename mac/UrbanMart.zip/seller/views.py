from django.shortcuts import render,redirect
from django.db import IntegrityError
from django.contrib.auth.models import User
from django.http import JsonResponse,HttpResponse
from django.contrib.auth import login,authenticate
from django.contrib.auth import logout as log_out
from shop.models import Product,Buyer,ProductReview,Orders,OrderUpdate,Expert,UserLikes
from warehouse.models import PendingInventoryTransfer
import shop.emailEcomWEB as emailEcomWEB
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist
from .Authentication import validateCredentials
import math,json,random
from datetime import date

def index(req):
    try:
        b=Buyer.objects.get(user=req.user)
        messages.error(req,'You do not have access to that page')
        return redirect('/shop/')
    except ObjectDoesNotExist as e:
        pass
    except TypeError as te:
        pass
    new_orders=0
    if req.user.is_authenticated:
        try:
            products=Product.objects.filter(seller=req.user.username)
            categories=Product.objects.filter(seller=req.user.username).values('category')
            no_of_orders = req.session.get('no_of_orders', 0)
            total_orders = Orders.objects.filter(sellers__contains='"'+req.user.username+'"').count()
            new_orders = total_orders - int(no_of_orders)
            print(total_orders,no_of_orders,new_orders)
        except ObjectDoesNotExist as e:
             params={"allprods":[],"count":0,"n":0}
             return render(req,'seller/index.html',params)
    else:
        products=Product.objects.all()
        categories=Product.objects.values('category')
    cat={item['category'] for item in categories}
    cat=list(cat)
    productTemp=[]
    allprods=[]
    nslides=0
    for i in cat:
        for j in products:
            if(j.category==i):
                productTemp.append(j)
        n=len(productTemp)
        nslides = n // 4 + math.ceil(n / 4 - (n // 4))
        allprods.append([productTemp.copy(),range(1,nslides),nslides])
        productTemp.clear()
    
    params={"allprods":allprods,"count":range(nslides),"n":nslides,"new_orders":new_orders}
    return render(req,'seller/index.html',params)
# Create your views here.


def signup(req):
    if req.method == 'POST':
        user_name = req.POST.get('name', '')
        email = req.POST.get('email', '')
        password = req.POST.get('password', '')
        try:         
            myuser = User.objects.create_user(username=user_name, email=email, password=password)
            myuser.save()
            login(myuser,password)
            messages.success(req, "Your account has been successfully created")
            return redirect('/seller/')
        except IntegrityError as e:
            messages.warning(req, "Username already exists! please try again with different username")
            return redirect('/seller/')
        except Exception as e1:
            messages.success(req, "Some error occured")
            return redirect('/seller/')
    return render('seller/index.html')  # Correct path to your template
def signin(req):
    if req.method == 'POST':
        user_name = req.POST.get('username', '')
        password = req.POST.get('password', '')
        user = authenticate(username=user_name, password=password)
        if user is not None:
            try:
                buyer = Buyer.objects.get(user=user)
                messages.error(req,'Authorization failed: You do not have access to the seller page.')
            except ObjectDoesNotExist:
                login(request=req, user=user)
                messages.success(req,'Successfully logged in!')
        else:
            messages.error(req,'Invalid Login!!')
    return redirect('/seller/')
def logout(req):
    if req.method=='POST':
        log_out(req)
        messages.success(req,'Log out successful!')
    return redirect('/seller/')
def productview(req,id):
    product=Product.objects.filter(id=id)
    reviews=ProductReview.objects.filter(product=product.first(),parent=None)
    reviewDict=[]
    for review in reviews:
        try:
            try:
                expert=Expert.objects.get(user=review.user,category=product.first().category)
            except:
                expert=None
            reviewTempList=[]
            user_like=UserLikes.objects.get(user=req.user)
            if '"'+str(review.sno)+'"' in user_like.liked:
                reviewTempList=["liked",review]
            elif '"'+str(review.sno)+'"' in user_like.disliked:
                reviewTempList=["disliked",review]
            else:
                reviewTempList=["neutral",review]
            if expert:
                reviewTempList.append('expert')
                reviewTempList.append(product.first().category)
            else:
                reviewTempList.append('not_expert')
            reviewDict.append(reviewTempList.copy())
            reviewTempList.clear()       
        except:
            reviewDict.append(["neutral",review])
    replies=[]
    ratingsFullstar=[]
    ratingsEmptystar=[]
    for review in reviews:
        ratingsFullstar.append(range(review.ratings))
        ratingsEmptystar.append(range(5-review.ratings))
    allReplies=ProductReview.objects.all().exclude(parent=None)
    if req.user.username != product.first().seller:
        pg_views=product.first()
        pg_views.views+=1
        pg_views.save()
    
    for reply in allReplies:
        try:
            expert=Expert.objects.get(user=reply.user,category=product.first().category)
        except:
            expert=None
        if reply.user.username==reply.product.seller:
            replies.append([reply,'seller'])
        elif expert:
            replies.append([reply,'expert',product.first().category])
        else:
            replies.append([reply,'buyer'])
    replyDict={}
    for i in replies:
        if i[0].parent.sno not in replyDict.keys():
            replyDict[i[0].parent.sno]=[i]
        else:
            replyDict[i[0].parent.sno].append(i)
    prod_user=product.first().seller
    restricted='Not restricted'
    if req.user.username==prod_user:
        restricted='restricted'
    print(reviewDict)
    return render(req,'seller/product.html',{'product':product[0],'reviews':reviewDict,'replies':replyDict,'ratingsFullstar':ratingsFullstar,'ratingEmptystar':ratingsEmptystar,'count':reviews.count(),'restricted':restricted})
def sendotp(req):
    if req.method == 'POST':
        email = req.POST.get('email1', '')
        
        # Debug statement to check if email is received
        print('Email received:', email)

        if email:
            otp = random.randint(100000, 999999)
            print('Generated OTP:', otp)

            try:
                emailEcomWEB.sendOtpMail(email, otp)
                print('OTP email sent to:', email)
                req.session['otp']=otp
                return JsonResponse({'msg': 'success','email':email})
            except Exception as e:
                print('Error sending OTP email:', str(e))
                return JsonResponse({'msg': 'error', 'error': str(e)})
        else:
            print('No email provided')
            return JsonResponse({'msg': 'no email'})
    return JsonResponse({'msg': 'invalid request'})
def signinwithotp(req):
    if req.method == 'POST':
        email=req.POST.get('hidden-email','')
        otpGet=req.POST.get('otp','')
        otp=req.session.get('otp',None)
        print('email: ',email,'otp from user: ',otpGet,'otp: ',otp)
        if(str(otp)==str(otpGet)):
            user=User.objects.filter(email=email).first()
            cart = Cart.objects.filter(username=user.username).first()
            cart_json = json.loads(cart.cart_json) if cart else {}
            login(req,user)
            messages.success(req,'Successfully logged in!!')
            return JsonResponse({
                'cart': cart_json,  # Return the JSON directly without escaping
                'redirect_url': '/shop/'
            })
            
        else:
            messages.error(req,'Wrong OTP!!')
    return redirect('/shop/')
def addproduct(req):
    if req.method=='POST':
        p_name=req.POST.get('product-name','')
        price=req.POST.get('price','')
        desc=req.POST.get('description','')
        category=req.POST.get('category','')
        subcategory=req.POST.get('subcategory','')
        stock=req.POST.get('total-stock','')
        keywords=req.POST.get('search-keywords','')
        p_plan=req.POST.get('product-plan','')
        image=req.FILES.get('product-image','')
        if '' in [p_name,price,desc,category,subcategory,stock,keywords,p_plan,image]:
            messages.warning(req,"All fields are must required!")
            return render(req,'seller/addproduct.html')
        if int(stock)<1:
            messages.error(req,'Stock should be greater than 0!!')
            return render(req,'seller/addproduct.html')
        
        product = PendingInventoryTransfer(
        p_name=p_name,
        p_date=date.today(),
        price=price,
        desc=desc,
        p_plan=p_plan,
        category=category,
        subcategory=subcategory,
        stock=stock,
        keywords=keywords,
        image=image,
        seller=req.user.username
        )
        product.save()
        emailEcomWEB.sendInventoryTransferMail(req.user.email,req.user.username)
        messages.warning(req,"Your product will not be listed until you transfer your inventory. For further details, please check your email.")
    return render(req,'seller/addproduct.html')
prod_plans={'platinum':0.20,'golden':0.13,'silver':0.07}
def checkOrders(req):
    orders=Orders.objects.all()
    myProdArray=[]   
    myproducts={}
    #{"user": {"seller1": [[2, 3]], "johndoe": [[3, 20]]}}
    myProdArray = []
    for order in orders:
        sellers_info = json.loads(order.sellers)
        user_sellers = sellers_info.get('user', {})
        if req.user.username in user_sellers:
            myOrderUpdates={}
            orderUpdates=OrderUpdate.objects.filter(order_id=order.id)
            print(order.id)
            for orderUpdate in orderUpdates:
                orderUpdateMessage=orderUpdate.update_desc
                substrings = ['placed','shipped','packed','delivered']
                for i in substrings:
                    if i in orderUpdateMessage.lower():
                        myOrderUpdates[i]=[True,orderUpdate.timestamp]
                    else:
                        try:
                            if myOrderUpdates[i][0]:
                                pass
                        except Exception as e:
                            myOrderUpdates[i]=[False]
                if('out for delivery' in orderUpdateMessage.lower()):
                    myOrderUpdates['out_for_delivery']=[True,orderUpdate.timestamp]
                else:
                    myOrderUpdates['out_for_delivery']=[False]
            myproducts = {}
            referral_fees=0
            for item in user_sellers[req.user.username]:
                product_id = item[1]
                quantity = item[0]
                product = Product.objects.get(id=product_id)
                referral_fees=prod_plans[product.p_plan]*product.price*quantity
                myproducts[product] = [quantity,myOrderUpdates,prod_plans[product.p_plan]*100,referral_fees,product.price*quantity-referral_fees]    
                
                
            myProdArray.append(myproducts)
            print(myProdArray)
    req.session['no_of_orders'] = len(myProdArray)
    #[{<Product: Boat Airbuds 141>: 2, <Product: Raybun Sunglass (1 item)>: 1}]
            
    return render(req,'seller/checkorders.html',{'products':myProdArray})
def pendingInventoryTransfers(req):
    if not req.user.is_authenticated:
        return HttpResponse('404-Not Found')
    inventoryTransfers=PendingInventoryTransfer.objects.filter(seller=req.user.username)
    return render(req,'seller/pending_inventory_transfers.html',{'products':inventoryTransfers})
def editProduct(req,id):
    if not req.user.is_authenticated:
        return HttpResponse('404-Not Found')
    product=Product.objects.get(id=id)
    if req.method=='POST':
        name = req.POST.get('name','')
        description = req.POST.get('description','')
        keywords = req.POST.get('keywords','')
        category = req.POST.get('category','')
        subcategory = req.POST.get('subcategory','')
        price = req.POST.get('price','')
        p_plan=req.POST.get('product-plan','')
        image = req.FILES.get('image')
        if image:
            product.image = image
        if name!='' and p_plan!='' and description!='' and keywords!='' and category!='' and subcategory!='' and price!='':
            product.p_name=name
            product.desc=description
            product.keywords=keywords
            product.category=category
            product.subcategory=subcategory
            product.price=price
            product.p_plan=p_plan
            product.save()
            messages.success(req,product.p_name+" has been edited successfully")
            return redirect('/seller/')
        else:
            messages.error(req,"Please fill all the fields")
    return render(req,'seller/editproduct.html',{'product':product})
def refillInventory(req,id):
    product=Product.objects.get(id=id)
    if req.method=='POST':
        stock = req.POST.get('stock','')
        emailEcomWEB.sendInventoryTransferOnRefillStockMail(req.user.email,req.user.email)
        if stock=='' or int(stock)<1:
            messages.error('Enter valid number')
        else:
            pendingInventoryTransfer=PendingInventoryTransfer(p_name=product.p_name,p_id=product.id,desc=product.desc,category=product.category,subcategory=product.subcategory,p_date=product.p_date,seller=product.seller,keywords=product.keywords,image=product.image,refill=True,stock=stock,price=product.price)
            pendingInventoryTransfer.save()
            messages.success(req,product.p_name+" has been added to pending inventory transfers")

    return render(req,'seller/refillstock.html',{'product':product})
