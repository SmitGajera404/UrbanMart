from django.db import models
from shop.models import Product
