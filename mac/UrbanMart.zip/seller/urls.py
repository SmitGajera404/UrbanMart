# shop/urls.py
from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'), 
    path('signin/',views.signin,name='signin'),
    path('sendotp/',views.sendotp,name='sendotp'),
    path('signinwithotp/',views.signinwithotp,name='signinwithotp'),
    path('signup/',views.signup,name='signup'),
    path('logout/',views.logout,name='logout'),
    path('productview/<int:id>',views.productview,name='productview'),
    path('addproduct/',views.addproduct,name='addproduct'),
    path('checkOrders/',views.checkOrders,name='checkOrders'),
    path('pendingInventoryTransfers/',views.pendingInventoryTransfers,name='pendingInventoryTransfers'),
    path('editProduct/<int:id>',views.editProduct,name='editProduct'),
    path('refillInventory/<int:id>',views.refillInventory,name='refillInventory')
]
