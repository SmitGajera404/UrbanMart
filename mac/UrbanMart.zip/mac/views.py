from django.http import HttpResponse
def index(req):
    return HttpResponse('<a href="/shop/">Shop</a><br><a href="/seller/">Seller</a><br><a href="/warehouse/">Warehouse</a>')