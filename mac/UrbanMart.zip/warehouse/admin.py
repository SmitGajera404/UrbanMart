from django.contrib import admin
from .models import PendingInventoryTransfer
admin.site.register(PendingInventoryTransfer)
# Register your models here.
